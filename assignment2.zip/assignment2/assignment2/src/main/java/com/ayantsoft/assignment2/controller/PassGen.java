package com.ayantsoft.assignment2.controller;

import org.passay.CharacterRule;
import org.passay.EnglishCharacterData;
import org.passay.LengthRule;
import org.passay.PasswordGenerator;

public class PassGen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		/*<dependency>
		<groupId>org.passay</groupId>
		<artifactId>passay</artifactId>
		<version>1.3.1</version>
	</dependency>*/

		PasswordGenerator gen = new PasswordGenerator();

		EnglishCharacterData lowerCaseChars = EnglishCharacterData.LowerCase;
		CharacterRule lowerCaseRule = new CharacterRule(lowerCaseChars);
		lowerCaseRule.setNumberOfCharacters(2);

		EnglishCharacterData upperCaseChars = EnglishCharacterData.UpperCase;
		CharacterRule upperCaseRule = new CharacterRule(upperCaseChars);
		upperCaseRule.setNumberOfCharacters(2);

		EnglishCharacterData digitChars = EnglishCharacterData.Digit;
		CharacterRule digitRule = new CharacterRule(digitChars);
		digitRule.setNumberOfCharacters(2);

		EnglishCharacterData splChars = EnglishCharacterData.Special;
		CharacterRule splCharRule = new CharacterRule(splChars);
		splCharRule.setNumberOfCharacters(2);


		String password = gen.generatePassword(10,lowerCaseRule,splCharRule, 
				upperCaseRule, digitRule);

			/*if(password.length()<=minlength) {
				//do your job here
			}*/

		System.out.print(password);
	}

}
