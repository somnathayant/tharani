package com.ayantsoft.assignment4.controller;


import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
public class EmpController {

	
	@RequestMapping("/")  
	public ModelAndView welcome() {  

		ModelAndView mv=new ModelAndView();
		mv.setViewName("automation1");
		return mv;
	}  
	
	@RequestMapping("/cl1")  
	public ResponseEntity<?> brokenMethod1() {  

		String response="error";

		return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);//Not 200
	}  

	@RequestMapping("/cl2")  
	public ResponseEntity<?> properMethod1() {  

			String response="ok";//ok means 200

		return new ResponseEntity<>(response,HttpStatus.OK);

	}  
	@RequestMapping("/cl3")  
	public ResponseEntity<?> properMethod2() {  

			String response="ok";//ok means 200

		return new ResponseEntity<>(response,HttpStatus.OK);

	}  
	@RequestMapping("/cl4")  
	public ResponseEntity<?> brokenMethod2() {  

		String response="error";

		return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);//Not 200

	}  
	@RequestMapping("/cl5")  
	public ResponseEntity<?> properMethod3() {  

			String response="ok";//ok means 200

		return new ResponseEntity<>(response,HttpStatus.OK);

	}  
	@RequestMapping("/cl6")  
	public ResponseEntity<?> brokenMethod3() {  

		String response="error";

		return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);//Not 200

	}  
	
}
