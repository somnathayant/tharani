package com.ayantsoft.assignment4.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class TestCase1 {
	WebDriver driver = new FirefoxDriver();

	@BeforeClass
	public void initialization() {
		System.setProperty("webdriver.gecko.driver","D:\\geckodriver.exe");
		String baseUrl = "http://localhost:8080/assignment4/";	
		driver.get(baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		try {
			File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			// now copy the  screenshot to desired location using copyFile //method
			FileUtils.copyFile(src, new File("E:/assignment4/TestCase_general_first_pic.png"));//path of image
		}
		catch(Exception ex) {}

	}

	@Test
	public void testCase1() {

		try {
			String url="";
			String ancharName;
			int response=200;
			HttpURLConnection huc = null;
		
			// start reporters
			ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("E:/assignment4/testcase1/TestCase 1.html");
			// create ExtentReports and attach reporter(s)
			ExtentReports extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			// creates a toggle for the given test, adds all log events under it    
			ExtentTest test = extent.createTest("This test for assignment4 has been started");

			test.log(Status.INFO,"Starting the test case 1");

								
			List<WebElement> links = driver.findElements(By.tagName("a"));
			System.out.println(links.size());
			test.log(Status.INFO,"Taking the List of Anchors");
			
			Iterator<WebElement> it = links.iterator();
				while(it.hasNext()){
				WebElement anchor=it.next();
				url = anchor.getAttribute("href");
				ancharName=anchor.getText();
				
				if(url == null || url.isEmpty()){
					System.out.println("URL is either not configured for anchor tag or it is empty");
					System.exit(0);
				}
				
				huc = (HttpURLConnection)(new URL(url).openConnection());

				huc.setRequestMethod("HEAD");

				huc.connect();
				
				test.log(Status.INFO,"Sending the request to server for finding the Link Status");
				response = huc.getResponseCode();

				if(response >= 400){
					test.log(Status.INFO,ancharName + " is a broken link with url = "+url);
				}
				else{
					test.log(Status.INFO,ancharName + " is a working link with url = "+url);
					
				}
			}
			extent.flush();
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());

		}
	}














}
