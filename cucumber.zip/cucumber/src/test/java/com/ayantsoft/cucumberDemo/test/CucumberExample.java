package com.ayantsoft.cucumberDemo.test;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class CucumberExample {

	CucumberLogic t1=new CucumberLogic();
	@Given("^calling browser screen$")
	public void calling_browser_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  t1.initialization();
	}

	@Then("^create report$")
	public void create_report() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 t1.TestCase1Implementation();
	}

	@Then("^calling another method$")
	public void calling_another_method() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.print("done");
	}

	
	
	
}
