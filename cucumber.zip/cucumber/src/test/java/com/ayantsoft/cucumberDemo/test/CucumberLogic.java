package com.ayantsoft.cucumberDemo.test;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;


public class CucumberLogic {

	WebDriver driver = new FirefoxDriver();

	
	public void initialization() {
		System.setProperty("webdriver.gecko.driver","D:\\geckodriver.exe");
		String baseUrl = "http://localhost:8080/cucumber/";	
		driver.get(baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	
	public void TestCase1Implementation() {

		try {

			// start reporters
			ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("E:/assignment2/TestCase1/TestCase 1.html");
			// create ExtentReports and attach reporter(s)
			ExtentReports extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			// creates a toggle for the given test, adds all log events under it    
			ExtentTest test = extent.createTest("This test for assignment2 has been started");

			test.log(Status.INFO,"Starting the test case 1 for counting html elements in the page");

			List<WebElement> textBoxList=driver.findElements(By.cssSelector("input[type=text]"));//textBoxes
			test.log(Status.INFO,"TextBoxes are in number = "+textBoxList.size());



			List<WebElement> passwordBoxList=driver.findElements(By.cssSelector("input[type=password]"));//passwordBoxes
			test.log(Status.INFO,"PasswordBoxes are in number = "+passwordBoxList.size());


			List<WebElement> links = driver.findElements(By.tagName("a"));//links
			test.log(Status.INFO,"Links are in number = "+links.size());


			Iterator<WebElement> it = links.iterator();

			while(it.hasNext()){
				WebElement anchor=it.next();
				System.out.println(anchor.getAttribute("href"));
				System.out.println(anchor.getText());

				test.log(Status.INFO,"Links href and Labels = "+anchor.getAttribute("href")+", "+anchor.getText());

			}

			List<WebElement> dropDownBoxes = driver.findElements(By.tagName("select"));//dropDowns
			test.log(Status.INFO,"DropDown Boxes are in number = "+dropDownBoxes.size());

			List<WebElement> radioButtons=driver.findElements(By.cssSelector("input[type=radio]"));//textBoxes
			test.log(Status.INFO,"Radio Buttons  are in number = "+radioButtons.size());

			List<WebElement> checkBoxes=driver.findElements(By.cssSelector("input[type=checkbox]"));//textBoxes
			test.log(Status.INFO,"Check Boxes  are in number = "+checkBoxes.size());



			test.log(Status.INFO,"All the html elements have been counted and displayed ");


			test.log(Status.PASS,"So test case1 is done ");

			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

			File src1= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			// now copy the  screenshot to desired location using copyFile //method
			FileUtils.copyFile(src1, new File("E:/assignment2/TestCase1/TestCase 1_pic.png"));//path of image
			extent.flush();

			



		}
		catch (IOException e)
		{
			System.out.println(e.getMessage());

		}
		catch(Exception ex) {

		}
	}




}
