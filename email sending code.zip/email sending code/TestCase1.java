package com.ayantsoft.assignment2.testcase;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;


public class TestCase1 {

	WebDriver driver = new FirefoxDriver();

	@BeforeClass
	public void initialization() {
		System.setProperty("webdriver.gecko.driver","D:\\geckodriver.exe");
		String baseUrl = "http://localhost:8080/assignment2/";	
		driver.get(baseUrl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	@Test
	public void TestCase1Implementation() {

		try {

			// start reporters
			ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("E:/assignment2/TestCase1/TestCase 1.html");
			// create ExtentReports and attach reporter(s)
			ExtentReports extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			// creates a toggle for the given test, adds all log events under it    
			ExtentTest test = extent.createTest("This test for assignment2 has been started");

			test.log(Status.INFO,"Starting the test case 1 for counting html elements in the page");

			List<WebElement> textBoxList=driver.findElements(By.cssSelector("input[type=text]"));//textBoxes
			test.log(Status.INFO,"TextBoxes are in number = "+textBoxList.size());



			List<WebElement> passwordBoxList=driver.findElements(By.cssSelector("input[type=password]"));//passwordBoxes
			test.log(Status.INFO,"PasswordBoxes are in number = "+passwordBoxList.size());


			List<WebElement> links = driver.findElements(By.tagName("a"));//links
			test.log(Status.INFO,"Links are in number = "+links.size());


			Iterator<WebElement> it = links.iterator();

			while(it.hasNext()){
				WebElement anchor=it.next();
				System.out.println(anchor.getAttribute("href"));
				System.out.println(anchor.getText());

				test.log(Status.INFO,"Links href and Labels = "+anchor.getAttribute("href")+", "+anchor.getText());

			}

			List<WebElement> dropDownBoxes = driver.findElements(By.tagName("select"));//dropDowns
			test.log(Status.INFO,"DropDown Boxes are in number = "+dropDownBoxes.size());

			List<WebElement> radioButtons=driver.findElements(By.cssSelector("input[type=radio]"));//textBoxes
			test.log(Status.INFO,"Radio Buttons  are in number = "+radioButtons.size());

			List<WebElement> checkBoxes=driver.findElements(By.cssSelector("input[type=checkbox]"));//textBoxes
			test.log(Status.INFO,"Check Boxes  are in number = "+checkBoxes.size());



			test.log(Status.INFO,"All the html elements have been counted and displayed ");


			test.log(Status.PASS,"So test case1 is done ");

			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

			File src1= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			// now copy the  screenshot to desired location using copyFile //method
			FileUtils.copyFile(src1, new File("E:/assignment2/TestCase1/TestCase 1_pic.png"));//path of image
			extent.flush();

			//email code starts here


			String username = "";//put here senders email
			String password = "";//put here senders email password; make sure you made email setting for less secure app enable from email account setting 
									//hints https://hotter.io/docs/email-accounts/secure-app-gmail/
			Properties props = new Properties();

			props.put("mail.smtp.host", "smtp.gmail.com");
			props.put("mail.smtp.user", username);
			props.put("mail.smtp.password", password);
			props.put("mail.smtp.auth", "true");
			props.put("mail.debug", true);
			props.put("mail.smtp.port", "587");
			//props.put("mail.smtp.port", "465");
			props.put("mail.transport.protocol", "smtp");
			props.put("mail.smtp.starttls.enable", "true");

			javax.mail.Session jmsession = javax.mail.Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(username, password);
				}
			});

			MimeMessage message = new MimeMessage(jmsession);
			message.setFrom(new InternetAddress(username));
			message.addRecipient(Message.RecipientType.TO,new InternetAddress("receiver email"));
			message.setSubject("Test Report");
			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setContent("This is test report", "text/html");

			Multipart multipart = new MimeMultipart();

			multipart.addBodyPart(messageBodyPart);

			messageBodyPart = new MimeBodyPart();
			String filename = "E:/assignment2/TestCase1/TestCase 1.html";
			DataSource source = new FileDataSource(filename);
			messageBodyPart.setDataHandler(new DataHandler(source));
			messageBodyPart.setFileName(filename);
			multipart.addBodyPart(messageBodyPart);

			// Send the complete message parts
			message.setContent(multipart);

			Transport transport = jmsession.getTransport("smtp");
			transport.connect();
			transport.sendMessage(message, message.getAllRecipients());
			transport.close();
			
			System.out.println("done");




		}
		catch (IOException e)
		{
			System.out.println(e.getMessage());

		}
		catch(Exception ex) {

		}
	}




}
