package com.ayantsoft.controller;


import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
public class EmpController {

	private Logger log = Logger.getLogger(EmpController.class);

	@RequestMapping("/")  
	public ModelAndView welcome() {  

		ModelAndView mv=new ModelAndView();
		mv.setViewName("login");
		return mv;
	}  
	
	@RequestMapping("/second")  
	public ModelAndView secondPage() {  

		ModelAndView mv=new ModelAndView();
		mv.setViewName("second");
		return mv;
	}  
	
	@RequestMapping("/popUpPage")  
	public ModelAndView popUpPage() {  

		ModelAndView mv=new ModelAndView();
		mv.setViewName("popUpPage");
		return mv;
	}  
	

	@RequestMapping("/brokenMethod")  
	public ResponseEntity<?> brokenMethod() {  

		String response="error";

		return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);//Not 200
	}  

	@RequestMapping("/properMethod")  
	public ResponseEntity<?> properMethod() {  

			String response="ok";//ok means 200

		return new ResponseEntity<>(response,HttpStatus.OK);

	}  
}
