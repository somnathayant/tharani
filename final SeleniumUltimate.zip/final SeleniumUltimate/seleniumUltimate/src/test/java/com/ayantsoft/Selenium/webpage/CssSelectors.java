package com.ayantsoft.Selenium.webpage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class CssSelectors {

	@Test
	public void testCssSelector(){

		WebDriver driver = new FirefoxDriver();

		String baseUrl = "http://localhost:8081/seleniumUltimate/";	
		driver.get(baseUrl);

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

/*		WebElement userId = driver.findElement(By.id("userid"));					 
		WebElement userPass = driver.findElement(By.id("password"));					 
		WebElement radioOption = driver.findElement(By.id("empType"));					 
		WebElement chk1 = driver.findElement(By.id("wage1"));					 
		WebElement chk2 = driver.findElement(By.id("wage2"));					 
		WebElement chk3 = driver.findElement(By.id("wage3"));					 
*/
		
		//using CSS Selector
		
		
		/*WebElement userId = driver.findElement(By.cssSelector(".usr-id"));					 
		WebElement userPass = driver.findElement(By.cssSelector(".usr-pass"));
							 
		WebElement radioOption = driver.findElement(By.id("empType"));					 
		
		WebElement chk1 = driver.findElement(By.cssSelector(".usr-chk1"));					 
		WebElement chk2 = driver.findElement(By.cssSelector(".usr-chk2"));					 
		WebElement chk3 = driver.findElement(By.cssSelector(".usr-chk3"));
	*/	
		
		//Multiple variation for CSS Selector
		/*WebElement userId = driver.findElement(By.cssSelector("input[id=userid][class=usr-id]"));*/					 
		
		/*WebElement userId = driver.findElement(By.cssSelector("input[id^='usr']"));	
		*/
		
		
		WebElement userId = driver.findElement(By.cssSelector("input[id$='id']"));	
		
		//WebElement userId = driver.findElement(By.cssSelector("input[id*='sr']"));	

		
		
		WebElement userPass = driver.findElement(By.cssSelector("input[id=password]"));					 
		WebElement radioOption = driver.findElement(By.id("empType"));					 
		WebElement chk1 = driver.findElement(By.cssSelector("input[id=wage1]"));					 
		WebElement chk2 = driver.findElement(By.cssSelector("input[id=wage2]"));					 
		WebElement chk3 = driver.findElement(By.cssSelector("input[id=wage3]"));
		
		
		
		
		
		radioOption.click();//checks the radio so validation wont work if you dont do it validation work
		chk1.click();
		//you can do same as of radio button with checkboxes namely chk1,chk2,chk3

		userId.sendKeys();//no words so validation works
		userPass.sendKeys("selenium@123");//password less or greater then 5 words so validation works

		JavascriptExecutor js =(JavascriptExecutor)driver;

		js.executeScript("done();");


		
		


	}

}
