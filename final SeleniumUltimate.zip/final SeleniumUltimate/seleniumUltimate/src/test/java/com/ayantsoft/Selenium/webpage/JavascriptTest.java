package com.ayantsoft.Selenium.webpage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class JavascriptTest {

	@Test
	public void fun(){
		
		/*System.setProperty("webdriver.chrome.driver", "D:\\3rdparty\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		*/
		
		/*System.setProperty("webdriver.firefox.marionette","C:\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
	*/
		
		
		
		
		
		
		WebDriver driver = new FirefoxDriver();
		
		
		String baseUrl = "http://localhost:8081/seleniumUltimate/";	
		
	    driver.get(baseUrl);
	    
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    
	    WebElement userId = driver.findElement(By.id("userid"));					 
	    WebElement userPass = driver.findElement(By.id("password"));					 
	     
	    WebElement radioOption = driver.findElement(By.id("empType"));					 
	    
	    
	    WebElement chk1 = driver.findElement(By.id("wage1"));					 
	    WebElement chk2 = driver.findElement(By.id("wage2"));					 
	    WebElement chk3 = driver.findElement(By.id("wage3"));					 
		   
	    radioOption.click();//checks the radio so validation wont work if you dont do it validation work
	    //chk1.click();
	    //you can do same as of radio button with checkboxes namely chk1,chk2,chk3
	    
	    userId.sendKeys();//no words so validation works
	    userPass.sendKeys("selenium@123");//password less or greater then 5 words so validation works
	    
	    JavascriptExecutor js =(JavascriptExecutor)driver;
	    
        js.executeScript("done();");
 
        
	}



}
